<!DOCTYPE html><html itemscope="itemscope" itemtype="http://schema.org/WebPage" lang="id-ID"><head><title>Internet Positif - Positifkan diri kamu</title><meta property="og:url" content="https://internetpositif.id"><meta property="og:title" content="Internet Positif - Positifkan diri kamu"><meta property="og:description" content="Halaman yang kamu tuju tidak dapat diakses"><meta property="og:site_name" content="uzone.id"><meta itemprop="name" content="Internet Positif - Positifkan diri kamu"><meta itemprop="description" content="Halaman yang kamu tuju tidak dapat diakses"><meta itemprop="image" content="https://cdn4.uzone.id/assets/uploads/wp/header.gif"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" type="image/x-icon" href="https://cdn4.uzone.id/assets/uploads/uzone_prime/favicon.gif"><style>body{margin:0;padding:0}.top-banner-section{background-color:#d00;margin:auto;text-align:center}.text-floating{background-color:#d00;padding:15px 0 0 0;position:fixed;bottom:0;left:0;right:0;text-align:center}.text-floating p{color:#fff}.top-banner-section img{width:100%}.item-list{margin:20px auto 40px auto}.item-list img{width:100%;margin-bottom:20px;border-radius:10px;height:150px;object-fit:cover}.item-list h4{font-size:16px;font-weight:700}.item-list a,.item-list a:hover{color:#333;text-decoration:none}.box-ads{text-align:center;margin:20px auto}.box-ads-mr{text-align:center;margin:20px auto}@media (min-width:320px) AND (max-width:768px){.top-banner-section{padding:40px 0}.item-list h4{font-size:11px;font-weight:700}.item-list img{margin-bottom:10px;border-radius:10px;height:100px}.item-list{margin:20px auto 0 auto}}</style><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"><script async src="https://www.googletagmanager.com/gtag/js?id=G-BPWBTPEH1Q"></script><script>function gtag(){dataLayer.push(arguments)}window.dataLayer=window.dataLayer||[],gtag("js",new Date),gtag("config","G-BPWBTPEH1Q")</script></head><body><main><section class="top-banner-section"><div class="container"><div class="row"><img src="https://cdn4.uzone.id/assets/uploads/wp/header.gif"></div></div></section><section class="main-body"><div class="container"><div class="row top-content"></div><div class="row" style="margin-bottom:30px"><div class="col-md-3 col-lg-3 col-xs-6 col-sm-6 col-6"><div class="item-list"><a href="https://uzone.id/warga-jakarta-perlu-tahu-begini-cara-cek-nik-aktif-secara-online"><div class="item-list-images"><img src="https://cdn4.uzone.id/assets/uploads/UZONEINC/digilife/KTP_Digital/ktp-digital-uzone.id.jpg/800"></div><div class="item-list-description"><h4>Warga Jakarta Perlu Tahu, Begini Cara Cek NIK Aktif Secara Online</h4></div></a></div></div><div class="col-md-3 col-lg-3 col-xs-6 col-sm-6 col-6"><div class="item-list"><a href="https://uzone.id/10-hp-android-paling-kencang-sedunia-banyak-dijual-di-indonesia"><div class="item-list-images"><img src="https://cdn4.uzone.id/assets/uploads/UZONEINC/gadget/Samsung/Galaxy_S24_Series/S24Uzone/galaxy-s24-series-online-exclusive2.jpg/800"></div><div class="item-list-description"><h4>10 HP Android Paling Kencang Sedunia, Banyak Dijual di Indonesia</h4></div></a></div></div><div class="col-md-3 col-lg-3 col-xs-6 col-sm-6 col-6"><div class="item-list"><a href="https://uzone.id/laku-1-200-unit-apa-sih-daya-tarik-suzuki-jimny-5-pintu-"><div class="item-list-images"><img src="https://cdn4.uzone.id/assets/uploads/UZONEINC/auto/Suzuki/Jimny/20240201_113311_copy_1600x900.jpg/800"></div><div class="item-list-description"><h4>Laku 1.200 Unit, Apa Sih Daya Tarik Suzuki Jimny 5 Pintu?</h4></div></a></div></div><div class="col-md-3 col-lg-3 col-xs-6 col-sm-6 col-6"><div class="item-list"><a href="https://uzone.id/mengenal-satelit-merah-putih-2-telkom-meluncur-pakai-roket-spacex"><div class="item-list-images"><img src="https://cdn4.uzone.id/assets/uploads/UZONEINC/telco/satelit/TELKOMSAT/telkom-telkomsat-satelit-merah-putih-2.jpg/800"></div><div class="item-list-description"><h4>Mengenal Satelit Merah Putih 2 Telkom, Meluncur Pakai Roket SpaceX</h4></div></a></div></div></div></div></section><section class="text-floating"><div class="container"><div class="row"><footer><p>Halaman ini akan tertutup secara otomatis pada detik ke<span class="counter"></span></p></footer></div></div></section></main></body><script src="https://code.jquery.com/jquery-3.6.0.min.js"></script><script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script><script>template = (e, i, t, a) => {
            $("." + e).append(
                '<div class="col-md-3 col-lg-3 col-xs-6 col-sm-6 col-6 ' +
                    a +
                    '"><div class="item-list"><a href="' +
                    i.slug +
                    '"><div class="item-list-images"><img src="' +
                    i.feature_img +
                    '"></div><div class="item-list-description"><h4>' +
                    i.post_title +
                    "</h4></div></a></div></div>"
            );
        };
        var device = "";
        (detectDevice = () =>
            /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(
                navigator.userAgent
            ) ||
            /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(
                navigator.userAgent.substr(0, 4)
            )
                ? ($(".slotAdsHeaderDesktop").html(""), (device = "mobile"))
                : ($(".slotAdsHeaderMobile").html(""), (device = "desktop"))),
            detectDevice();
        const url = "https://apis1.uzone.id/uzone/getDataInpos";
        axios.get(url).then((e) => {
            var i = 0;
            for (const t of e.data)
                (i += 1) <= 14 && (1 === i || (5 === i ? "mobile" === device && template("top-content", t, "top", i) : 6 === i ? (template("top-content", t, "top", i), templateMgid()) : template("top-content", t, "top", i)));
        }),
            "mobile" === device
                ? ((templateMgid = () => {
                      $(".mgid").append('<div id="M709336ScriptRootC1224345"></div>');
                      var e = document.createElement("script");
                      (e.src = "https://jsc.mgid.com/i/n/internetpositif.id.1224345.js"), (e.async = !0), $(".mgid").append(e);
                  }),
                  (templateAdsMR = () => {
                      $(".top-content").append(
                          '<div class="col-md-12 col-lg-12 col-xs-12 col-12"><div class="box-ads-mr"><iframe id="a9b3bef7? name="a9b3bef7" src="https://a03.uadexchange.com/delivery/afr.php?zoneid=7" frameborder="0" scrolling="no" width="300" height="250" allow="autoplay"></iframe></div></div>'
                      );
                  }),
                  (templateMgid = () => {
                      $(".top-content").append('<div style="clear:both;"></div><div class="col-md-12 col-12"><div class="mgid"></div></div>'), $(".mgid").append('<div id="M709336ScriptRootC1410228"></div>');
                      var e = document.createElement("script");
                      (e.src = "https://jsc.mgid.com/i/n/internetpositif.id.1410228.js"), (e.async = !0), $(".mgid").append(e);
                  }))
                : ((templateAds = () => {
                      $(".top-content").append(
                          '<div style="clear:both;"></div><div class="col-md-12 col-12"><div class="box-ads"><iframe id="a9efa36d" name="a9efa36d" src="https://a03.uadexchange.com/delivery/afr.php?zoneid=6" frameborder="0" scrolling="no" width="728" height="90" allow="autoplay"></iframe></div></div>'
                      );
                  }),
                  (templateAdsMR = () => {
                      $(".top-content").append(
                          '<div class="col-md-3 col-lg-3 col-xs-6 col-6"><div class="box-ads-mr"><iframe id="a9b3bef7? name="a9b3bef7" src="https://a03.uadexchange.com/delivery/afr.php?zoneid=7" frameborder="0" scrolling="no" width="300" height="250" allow="autoplay"></iframe></div></div>'
                      );
                  }),
                  (templateMgid = () => {
                      $(".top-content").append('<div style="clear:both;"></div><div class="col-md-12 col-12"><div class="mgid"></div></div>'), $(".mgid").append('<div id="M709336ScriptRootC1410228"></div>');
                      var e = document.createElement("script");
                      (e.src = "https://jsc.mgid.com/i/n/internetpositif.id.1410228.js"), (e.async = !0), $(".mgid").append(e);
                  }));
        var timeleft = 5,
            downloadTimer = setInterval(function () {
                timeleft < 0 ? (window.location.href = "https://redirect.uzone.co.id/api/list_push") : ($(".counter").html(timeleft), (timeleft -= 1));
            }, 1e3);</script></html>